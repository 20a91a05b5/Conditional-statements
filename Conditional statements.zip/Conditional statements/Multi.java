import java.util.*;
class Multi{
    public static void main(String args[])
    {
        Scanner a=new Scanner(System.in);
        
        int b=a.nextInt();
        while(b!=11)
        {
            System.out.println(5+" * "+b+" = "+(5*b));
            b++;
        }
    }
}